package border;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.util.ArrayList;

public class BorderDAO {
	private Connection conn;
	private PreparedStatement pstmt;
	private ResultSet rs;
	
	// DB �����κ�
	public BorderDAO() {
		try {
			String dbURL = "jdbc:mysql://localhost:3306/bbs_db";	// MySQL �ּ� 
			String dbID = "root";	//MySQL ID
			String dbPassword = "root";	//MySQL PASSWORD
			Class.forName("com.mysql.cj.jdbc.Driver");
			conn=DriverManager.getConnection(dbURL, dbID, dbPassword);	//DB ����
			
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	// ��� �ҷ�����
	public ArrayList<Border> getList(){
		String SQL = "select num, title from border order by num desc";
		
		ArrayList<Border> list = new ArrayList<Border>();
		try {
			PreparedStatement pstmt = conn.prepareStatement(SQL);
			rs=pstmt.executeQuery();
			while(rs.next()) {
				Border border = new Border();
				border.setNum(rs.getInt(1));
				border.setTitle(rs.getString(2));
				list.add(border);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	// ���� �б�
	public Border getBorder(int num) {
		String SQL = "select * from border where num = ?";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setInt(1, num);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				Border border = new Border();
				border.setNum(rs.getInt(1));
				border.setTitle(rs.getString(2));
				border.setContent(rs.getString(3));
				return border;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	// ���� ����
	public int write(String title, String content) {
		String SQL = "insert into border values(null, ?, ?)";
		try {
			PreparedStatement pstmt=conn.prepareStatement(SQL);
			pstmt.setString(1, title);
			pstmt.setString(2, content);
			return pstmt.executeUpdate();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	
	
}
